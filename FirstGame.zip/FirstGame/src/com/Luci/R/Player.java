package com.Luci.R;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.lang.annotation.Repeatable;

public class Player extends JPanel implements ActionListener,KeyListener {
    private Image Player1;
    private Timer P,M,S;
    public int xP,yP,velx,vely = 0;

    public int getxP() {
        return xP;
    }

    public int getyP() {
        return yP;
    }

    public Player() {
            super.setDoubleBuffered(true);
            addKeyListener(this);
            P = new Timer(5,this);
             P.start();
            setFocusable(true);
            setFocusTraversalKeysEnabled(false);
        }
    public void draw(Graphics2D g2d){
        super.paint(g2d);
        this.paintComponent(g2d);
        ImageIcon U = new ImageIcon(getClass().getResource("Player123.png"));
        Player1 = U.getImage();
        g2d.drawImage(Player1, xP, yP,this);
    }

        public void actionPerformed(ActionEvent e) {
            repaint();

            xP += velx;
            yP += vely;

            if(xP < -100){
                xP = -99 ;
                //affects top up
            }
            if(yP< -120){
                yP =-119;
                //affects middle left
            }
            if(xP>380)
                xP = 380;
            //affects middle right
            if(yP > 350)
                yP =350;
            //affects bottom down
        }
        private void up(){
            vely=-1;
            velx = 0;
        }
        private void down(){
            vely = 1;
            velx = 0;
        }
        private void  left(){
            vely = 0;
            velx = -1;
        }
        private void right(){
            vely = 0;
            velx = 1;
        }
        private void SpeedUp() {

            M = new Timer(1,this);
            M.start();
            M.setRepeats(false);

            if(P.isRunning()==true && M.isRunning()==true){
                P.stop();
                M.restart();

            }else if(M.isRunning()==false && P.isRunning()==true){
                P.stop();
                M.start();
            }
            else if(M.isRunning()==false && P.isRunning()==false){
                M.start();
            }
            else if(S.isRunning()==true&& M.isRunning()==true){
                S.stop();
                M.restart();
            }
            else if(S.isRunning()==true && M.isRunning()==false){
                S.stop();
                M.start();
            }
            else{
                setVisible(false);
            }



        }
        private void SlowDown() {

            S = new Timer(100, this);
            S.start();
            S.setRepeats(false);

            if(P.isRunning() && S.isRunning()){
                P.stop();
                S.restart();

              }else if(!S.isRunning() && P.isRunning()){
                P.stop();
                S.start();
            }
            else if(!S.isRunning() && !P.isRunning()){
                S.start();
            }
            else if(M.isRunning()&& S.isRunning()){
                M.stop();
                S.restart();
            }
            else if(M.isRunning() && !S.isRunning()){
                M.stop();
                S.start();
            }
            else{
                setVisible(false);
            }

        }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    public void keyPressed(KeyEvent e){
        try{
        int code = e.getKeyCode();
            if(code == KeyEvent.VK_W)
                up();
            if(code == KeyEvent.VK_S)
                down();
            if (code == KeyEvent.VK_A)
                left();
            if (code == KeyEvent.VK_D)
                right();
            if(code==KeyEvent.VK_Q)
               SpeedUp();
            if(code==KeyEvent.VK_P) {
                SlowDown(); }





}catch(Exception k){
            System.out.println("You have a error");
        }


}

    @Override
    public void keyReleased(KeyEvent e) {

    }

}











