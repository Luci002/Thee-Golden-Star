package com.Luci.R;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Enemy extends JPanel implements KeyListener,ActionListener  {
    private int x,y = 0;
    private int velx = 60;
    private Image Enemy1;
            private int vely = 60;

    private Timer L;
    public void draw(Graphics2D g2d){
        ImageIcon EP = new ImageIcon(getClass().getResource("Enemy123.png"));
        Enemy1 = EP.getImage();
        Player pp = new Player();

        g2d.drawImage(Enemy1,pp.getxP(),pp.getyP(),this);



    }
    public Enemy(){
        super.setDoubleBuffered(true);
        addKeyListener(this);
        L= new Timer(10,this);
        L.start();
        L.setRepeats(true);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);



    }
/*
if x, then y
t t t
t f
f t
f f
 */
    @Override
    public void actionPerformed(ActionEvent e) {
        repaint();
        x+=velx;
        y+=vely;
        if(x<5){
            x =5;
        }
        if(y<5){
            y = 5;
        }
        if(x>434)
            x = 34;
        if(y > 430)
            y =30;

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}



