package com.Luci.R;
import javax.swing.*;
import javax.swing.Timer;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.util.*;
public class Level1 extends Player {
public int u,l;
    private Image Background123;
    Player Y;
    Enemy E;
   public Level1(){

       Y = new Player();
        addKeyListener(Y);
    E = new Enemy();
    addKeyListener(E);




    }



    public void paint(Graphics g) {
        super.paint(g);
        this.paintComponent(g);
        Graphics2D g2d = (Graphics2D)g;

        ImageIcon Z = new ImageIcon(getClass().getResource("BackGroundP.png"));
        Background123 = Z.getImage();
        g2d.drawImage(Background123,0,0,this);

       Y.draw(g2d);
       E.draw(g2d);





    }








    }

