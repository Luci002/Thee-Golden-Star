package com.Luci.R;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        JFrame f = new JFrame("Program");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	Level1 L = new Level1();
	f.add(L);
	f.setSize(500,530);
	f.setLocationRelativeTo(null);
	f.setResizable(true);
		f.setVisible(true);
    }
}
